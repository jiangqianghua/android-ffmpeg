#include <jni.h>
#include <android/log.h>
#include <stdio.h>
#include <stdbool.h>
#include <pthread.h>
#include <unistd.h>
#include "libavformat/avformat.h"
#include "libavcodec/avcodec.h"
#include "libavcodec/version.h"
#include "libavutil/channel_layout.h"
#include "libavutil/common.h"
#include "libavutil/imgutils.h"
#include "libavutil/mathematics.h"
#include "libavutil/samplefmt.h"
#include "libavutil/avutil.h"
#include "libavformat/avformat.h"
#include "libavfilter/avfilter.h"
#include "libswscale/swscale.h"
#include "libswresample/swresample.h"

#define OPEN_LOG

#define LOG_TAG    "MediaPushCameraJni"
#undef LOG
#ifdef  OPEN_LOG
#define LOGD(...)  __android_log_print(ANDROID_LOG_DEBUG,LOG_TAG,__VA_ARGS__)
#define LOGI(...)  __android_log_print(ANDROID_LOG_INFO,LOG_TAG,__VA_ARGS__)
#define LOGW(...)  __android_log_print(ANDROID_LOG_WARN,LOG_TAG,__VA_ARGS__)
#define LOGE(...)  __android_log_print(ANDROID_LOG_ERROR,LOG_TAG,__VA_ARGS__)
#define LOGF(...)  __android_log_print(ANDROID_LOG_FATAL,LOG_TAG,__VA_ARGS__)
#else
#define LOGD(...)
#define LOGI(...)
#define LOGW(...)
#define LOGE(...)
#define LOGF(...)
#endif

 AVFormatContext *ofmt_ctx;
AVStream* video_st;
//视音频流对应的结构体，用于视音频编解码。
AVCodecContext* pCodecCtx;
AVCodec* pCodec;
AVPacket enc_pkt; // 存储压缩数据（视频对应H.264等码流数据，音频对应AAC/MP3等码流数据）
AVFrame *pFrameYUV; // 存储非压缩的数据（视频对应RGB/YUV像素数据，音频对应PCM采样数据）

int framecnt = 0;
int yuv_width;
int yuv_height;
int y_length;
int uv_length;
int64_t start_time;

// 参考地址 https://www.jianshu.com/p/462e489b7ce0
// 推送本地摄像头
// 初始化参数
JNIEXPORT int Java_com_jqh_jni_nativejni_MediaPlayerJni_pushCameraInit(JNIEnv *env,jobject jobject,
                                                            jstring url_,jint width, jint height)
{
	const char *out_path = (*env)->GetStringUTFChars(env,url_,0);
	LOGD("output url : %s" , out_path);

	yuv_width = width;
    yuv_height = height;
    y_length = width * height;
    uv_length = width * height / 4;

    //FFmpeg av_log() callback
   // av_log_set_callback(custom_log);

    av_register_all();

    avformat_network_init();

    //output initialize
    avformat_alloc_output_context2(&ofmt_ctx, NULL, "flv", out_path);
    //output encoder initialize
    //函数的参数是一个解码器的ID，返回查找到的解码器（没有找到就返回NULL）。
    pCodec = avcodec_find_encoder(AV_CODEC_ID_H264);
    if (!pCodec) {
        LOGE("Can not find encoder1111!\n");
        return -1;
    }
    LOGE("-----1111!\n");
    pCodecCtx = avcodec_alloc_context3(pCodec);
    pCodecCtx->pix_fmt = PIX_FMT_YUV420P;
    pCodecCtx->width = width;
    pCodecCtx->height = height;
    pCodecCtx->time_base.num = 1;
    pCodecCtx->time_base.den = 25;
    pCodecCtx->bit_rate = 400000;
    pCodecCtx->gop_size = 250;
    /* Some formats want stream headers to be separate. */
    if (ofmt_ctx->oformat->flags & AVFMT_GLOBALHEADER)
        pCodecCtx->flags |= CODEC_FLAG_GLOBAL_HEADER;

    //H264 codec param
    //pCodecCtx->me_range = 16;
    //pCodecCtx->max_qdiff = 4;
    //pCodecCtx->qcompress = 0.6;
    pCodecCtx->qmin = 10;
    pCodecCtx->qmax = 51;
    //Optional Param
    pCodecCtx->max_b_frames = 1;
    // Set H264 preset and tune
    AVDictionary *param = 0;
//  av_dict_set(&param, "preset", "ultrafast", 0);
//  av_dict_set(&param, "tune", "zerolatency", 0);
    av_opt_set(pCodecCtx->priv_data, "preset", "superfast", 0);
    av_opt_set(pCodecCtx->priv_data, "tune", "zerolatency", 0);
    //打开编码器
    if (avcodec_open2(pCodecCtx, pCodec, &param) < 0) {
        LOGE("Failed to open encoder!\n");
        return -1;
    }

    //Add a new stream to output,should be called by the user before avformat_write_header() for muxing
    video_st = avformat_new_stream(ofmt_ctx, pCodec);
    if (video_st == NULL) {
        return -1;
    }
    video_st->time_base.num = 1;
    video_st->time_base.den = 25;
    video_st->codec = pCodecCtx;

    //Open output URL,set before avformat_write_header() for muxing
    if (avio_open(&ofmt_ctx->pb, out_path, AVIO_FLAG_READ_WRITE) < 0) {
        LOGE("Failed to open output file!\n");
        return -1;
    }

    //Write File Header
    avformat_write_header(ofmt_ctx, NULL);

    start_time = av_gettime();
    return 0;
}

// 开始刷视频
JNIEXPORT int Java_com_jqh_jni_nativejni_MediaPlayerJni_pushCameraOnFrame(JNIEnv *env,jobject jobject,
                                                            jbyteArray buffer_)
{
	int ret;
    int enc_got_frame = 0;
    int i = 0;

    // 为解码帧分配内存
    pFrameYUV = av_frame_alloc();
    uint8_t *out_buffer = (uint8_t *) av_malloc(
            avpicture_get_size(PIX_FMT_YUV420P, pCodecCtx->width,
                    pCodecCtx->height));
    avpicture_fill((AVPicture *) pFrameYUV, out_buffer, PIX_FMT_YUV420P,
            pCodecCtx->width, pCodecCtx->height);

    //安卓摄像头数据为NV21格式，此处将其转换为YUV420P格式
    jbyte* in = (jbyte*) (*env)->GetByteArrayElements(env, buffer_, 0);
    memcpy(pFrameYUV->data[0], in, y_length);
    for (i = 0; i < uv_length; i++) {
        *(pFrameYUV->data[2] + i) = *(in + y_length + i * 2);
        *(pFrameYUV->data[1] + i) = *(in + y_length + i * 2 + 1);
    }

    pFrameYUV->format = AV_PIX_FMT_YUV420P;
    pFrameYUV->width = yuv_width;
    pFrameYUV->height = yuv_height;

    enc_pkt.data = NULL;
    enc_pkt.size = 0;
    // 定义AVPacket对象后,请使用av_init_packet进行初始化
    av_init_packet(&enc_pkt);

    /** 编码一帧视频数据
     * int avcodec_encode_video2(AVCodecContext *avctx, AVPacket *avpkt,
     const AVFrame *frame, int *got_packet_ptr);

     该函数每个参数的含义在注释里面已经写的很清楚了，在这里用中文简述一下：
     avctx：编码器的AVCodecContext。
     avpkt：编码输出的AVPacket。
     frame：编码输入的AVFrame。
     got_packet_ptr：成功编码一个AVPacket的时候设置为1。
     函数返回0代表编码成功。

     */
    ret = avcodec_encode_video2(pCodecCtx, &enc_pkt, pFrameYUV, &enc_got_frame);
    av_frame_free(&pFrameYUV);

    if (enc_got_frame == 1) {
        LOGI("Succeed to encode frame: %5d\tsize:%5d\n", framecnt,
                enc_pkt.size);
        framecnt++;
        //标识该AVPacket所属的视频/音频流。
        enc_pkt.stream_index = video_st->index; //标识该视频/音频流

        //Write PTS
        AVRational time_base = ofmt_ctx->streams[0]->time_base; //{ 1, 1000 };
        AVRational r_framerate1 = { 60, 2 };    //{ 50, 2 };
        AVRational time_base_q = { 1, AV_TIME_BASE };
        //Duration between 2 frames (us)
        int64_t calc_duration = (double) (AV_TIME_BASE)
                * (1 / av_q2d(r_framerate1));   //内部时间戳
        //Parameters
        //enc_pkt.pts = (double)(framecnt*calc_duration)*(double)(av_q2d(time_base_q)) / (double)(av_q2d(time_base));
        enc_pkt.pts = av_rescale_q(framecnt * calc_duration, time_base_q,
                time_base);
        enc_pkt.dts = enc_pkt.pts;
        enc_pkt.duration = av_rescale_q(calc_duration, time_base_q, time_base); //(double)(calc_duration)*(double)(av_q2d(time_base_q)) / (double)(av_q2d(time_base));
        enc_pkt.pos = -1;

        //Delay
        int64_t pts_time = av_rescale_q(enc_pkt.dts, time_base, time_base_q);
        int64_t now_time = av_gettime() - start_time;
        if (pts_time > now_time)
            av_usleep(pts_time - now_time);

        ret = av_interleaved_write_frame(ofmt_ctx, &enc_pkt);
        av_free_packet(&enc_pkt);
    }
//  output(ofmt_ctx);
    return 0;
}

